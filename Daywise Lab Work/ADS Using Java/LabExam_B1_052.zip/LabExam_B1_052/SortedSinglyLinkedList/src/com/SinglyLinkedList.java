package com;

//Class Node
class Node {
	int value;
	Node next;

	public Node(int value) {
		this.value = value;
		this.next = null;
	}
}

//Create a SinglyLinkedList Class
public class SinglyLinkedList {
	Node head;

	// adds a new node with a given value to the linked list.
	public void add(int X) {
		Node newNode = new Node(X);
		if (head == null || X < head.value) {
			newNode.next = head;
			head = newNode;
		} else {
			Node current = head;
			while (current.next != null && current.next.value < X) {

				current = current.next;
			}
			newNode.next = current.next;
			current.next = newNode;
		}
	}

	// takes an array of values and adds them one by one
	// to the linked list using the add method.
	public void addAll(int[] list_of_X) {
		for (int x : list_of_X) {
			add(x);
		}
	}

	// removes the node at the specified index from the linked list
	public void remove(int i) {
		if (head == null) {
			return;
		}
		if (i == 0) {
			head = head.next;
			return;
		}
		Node current = head;
		Node prev = null;
		int count = 0;
		while (current != null && count != i) {
			prev = current;
			current = current.next;
			count++;
		}
		if (count == i && current != null) {
			prev.next = current.next;
		}
	}

	// returns a string representation of the linked list
	public String toString() {
		StringBuilder sb = new StringBuilder();
		Node current = head;
		while (current != null) {
			sb.append(current.value);
			if (current.next != null) {
				sb.append(", ");
			}
			current = current.next;
		}
		return sb.toString();
	}
}