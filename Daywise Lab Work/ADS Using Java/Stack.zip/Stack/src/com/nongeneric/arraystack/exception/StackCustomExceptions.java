package com.nongeneric.arraystack.exception;

public class StackCustomExceptions extends Exception{

	public StackCustomExceptions(String errMsg)
	{
		super(errMsg);
		// TODO Auto-generated constructor stub
	}
	
}
