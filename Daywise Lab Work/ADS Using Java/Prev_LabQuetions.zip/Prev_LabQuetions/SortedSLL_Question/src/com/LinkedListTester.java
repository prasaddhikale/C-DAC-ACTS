package com;

import java.util.Scanner;

public class LinkedListTester {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SortedSinglyLinkedList sortedList = new SortedSinglyLinkedList();
        boolean exit = false;

        while (!exit) {
            System.out.println("\nEnter your choice:");
            System.out.println("1. Add element");
            System.out.println("2. Add a list of elements");
            System.out.println("3. Remove element at index");
            System.out.println("4. Display list");
            System.out.println("5. Exit");

            try {
                System.out.print("Enter your choice (1-5): ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        System.out.print("Enter element to add: ");
                        int element = scanner.nextInt();
                        sortedList.add(element);
                        break;
                    case 2:
                        System.out.print("Enter list of elements separated by space: ");
                        scanner.nextLine(); // Consume newline character
                        String elementsInput = scanner.nextLine();
                        String[] elements = elementsInput.split("\\s+");
                        int[] listToAdd = new int[elements.length];
                        for (int i = 0; i < elements.length; i++) {
                            listToAdd[i] = Integer.parseInt(elements[i]);
                        }
                        sortedList.addAll(listToAdd);
                        break;
                    case 3:
                        System.out.print("Enter index to remove: ");
                        int indexToRemove = scanner.nextInt();
                        sortedList.remove(indexToRemove);
                        break;
                    case 4:
                        System.out.println("Sorted List: " + sortedList);
                        break;
                    case 5:
                        exit = true;
                        System.out.println("Exiting...");
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter a valid option (1-5).");
                        break;
                }
            } catch (java.util.InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid integer.");
                scanner.nextLine(); // Clear the invalid input
            } catch (NumberFormatException e) {
                System.out.println("Invalid input for elements. Please enter integers separated by spaces.");
            }
        }

        scanner.close();
    }
}
