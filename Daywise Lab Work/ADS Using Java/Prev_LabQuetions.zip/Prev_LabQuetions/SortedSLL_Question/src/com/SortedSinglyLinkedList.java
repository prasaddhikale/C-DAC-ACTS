//Design a custom sorted singly linked list which supports following operations: 
//1.	add(X) � Add element X such that list remains sorted.
//2.	addAll(List of X) � Adds given list of X to the current list such that list remains sorted.
//3.	remove(X, i) � Remove element present at index i 
//4.	toString() � Returns comma separated elements from start to end
//
//Marks distribution: 
//1.	Basic structure of classes                  [10]
//2.	Implementation of add(X)                    [10]
//3.	Implementation of addAll(List<X>)           [10]
//4.	Implementation of remove(X, i)              [5]
//5.	Implementation of toString()                [5]


package com;

class Node {
    int value;
    Node next;

    public Node(int value) {
        this.value = value;
        this.next = null;
    }
}

class SortedSinglyLinkedList {
    Node head;

    public void add(int X) {
        Node newNode = new Node(X);
        if (head == null || X < head.value) {
            newNode.next = head;
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null && current.next.value < X) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    public void addAll(int[] list_of_X) {
        for (int x : list_of_X) {
            add(x);
        }
    }

    public void remove(int i) {
        if (head == null) {
            return;
        }
        if (i == 0) {
            head = head.next;
            return;
        }
        Node current = head;
        Node prev = null;
        int count = 0;
        while (current != null && count != i) {
            prev = current;
            current = current.next;
            count++;
        }
        if (count == i && current != null) {
            prev.next = current.next;
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        Node current = head;
        while (current != null) {
            sb.append(current.value);
            if (current.next != null) {
                sb.append(", ");
            }
            current = current.next;
        }
        return sb.toString();
    }
}
