//Write a Circular Queue using array in Java which implements the following interface:  
//public interface ICircularQueue {
//	
//	// Add the given element at the REAR of the queue
//	// Returns false if queue is full otherwise true is returned
//	boolean add(String element);
//	
//	// Remove element from the FRONT of the queue
//	// Returns null if the queue is empty
//	String remove();
//	
//	// Returns the total number of elements stored in the queue
//	// Returns 0 if the queue is empty
//	int size();
//	
//	// Returns comma separated elements from FRONT to REAR
//     // Returns empty string if queue is empty
//	String toString();
//}
//Verify each functionality either in Main class or by writing Junit test cases.
//
//Marks distribution: 
//1.	Basic structure of class                      [5]
//2.	Logic for isEmpty() and isFull()              [10]
//3.	Implementation of add()                       [5]
//4.	Implementation of remove()                    [5]
//5.	Implementation of size()                      [5]
//6.	Implementation of toString()                  [5]
//7.	Main driver class or Junit       �������������[5]


package com;

public class CircularQueue {
    private int front, rear, size;
    private final int capacity;
    private final String[] elements;

    public CircularQueue(int capacity) {
        this.capacity = capacity;
        this.elements = new String[capacity];
        this.front = 0;
        this.rear = -1;
        this.size = 0;
    }

    public boolean add(String element) {
        if (isFull()) {
            return false;
        }
        rear = (rear + 1) % capacity;
        elements[rear] = element;
        size++;
        return true;
    }

    public String remove() {
        if (isEmpty()) {
            return null;
        }
        String removedElement = elements[front];
        elements[front] = null;
        front = (front + 1) % capacity;
        size--;
        return removedElement;
    }

    public int size() {
        return size;
    }

    public String toString() {
        if (isEmpty()) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        int count = 0;
        int index = front;
        while (count < size) {
            sb.append(elements[index]);
            if (count < size - 1) {
                sb.append(", ");
            }
            index = (index + 1) % capacity;
            count++;
        }
        return sb.toString();
    }

    private boolean isFull() {
        return size == capacity;
    }

    private boolean isEmpty() {
        return size == 0;
    }
}

