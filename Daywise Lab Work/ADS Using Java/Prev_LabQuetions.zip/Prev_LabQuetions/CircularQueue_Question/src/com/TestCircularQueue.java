package com;

import java.util.Scanner;

public class TestCircularQueue {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CircularQueue queue = new CircularQueue(5);
        boolean exit = false;

        while (!exit) {
            System.out.println("\nEnter your choice:");
            System.out.println("1. Add element");
            System.out.println("2. Remove element");
            System.out.println("3. Display queue");
            System.out.println("4. Check queue size");
            System.out.println("5. Exit");

            try {
                System.out.print("Enter your choice (1-5): ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        System.out.print("Enter element to add: ");
                        String elementToAdd = scanner.next();
                        boolean added = queue.add(elementToAdd);
                        if (!added) {
                            System.out.println("Queue is full. Element not added.");
                        }
                        break;
                    case 2:
                        String removedElement = queue.remove();
                        if (removedElement == null) {
                            System.out.println("Queue is empty. No element removed.");
                        } else {
                            System.out.println("Removed element: " + removedElement);
                        }
                        break;
                    case 3:
                        System.out.println("Queue: " + queue.toString());
                        break;
                    case 4:
                        System.out.println("Queue size: " + queue.size());
                        break;
                    case 5:
                        exit = true;
                        System.out.println("Exiting...");
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter a valid option (1-5).");
                        break;
                }
            } catch (java.util.InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid option (1-5).");
                scanner.nextLine(); // Clear the invalid input
            }
        }

        scanner.close();
    }
}