package com;

import java.util.Scanner;

public class LinkedListTester {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SinglyLinkedList list = new SinglyLinkedList();

        boolean exit = false;
        while (!exit) {
            System.out.println("\nOperations:");
            System.out.println("1. Add element at end");
            System.out.println("2. Add element at index");
            System.out.println("3. Remove element");
            System.out.println("4. Display list");
            System.out.println("5. Reverse list");
            System.out.println("6. Exit");

            try {
                System.out.print("Enter your choice (1-6): ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        System.out.print("Enter element to add at end: ");
                        int element = scanner.nextInt();
                        list.add(element);
                        break;
                    case 2:
                        System.out.print("Enter element to add: ");
                        int el = scanner.nextInt();
                        System.out.print("Enter index to add at: ");
                        int index = scanner.nextInt();
                        list.add(el, index);
                        break;
                    case 3:
                        System.out.print("Enter element to remove: ");
                        int rem = scanner.nextInt();
                        list.remove(rem);
                        break;
                    case 4:
                        System.out.print("List: ");
                        list.list();
                        break;
                    case 5:
                        list.reverse();
                        System.out.println("List reversed!");
                        break;
                    case 6:
                        exit = true;
                        System.out.println("Exiting...");
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter a valid option (1-6).");
                        break;
                }
            } catch (java.util.InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid integer.");
                scanner.nextLine(); // Clear the invalid input
            }
        }

        scanner.close();
    }
}
