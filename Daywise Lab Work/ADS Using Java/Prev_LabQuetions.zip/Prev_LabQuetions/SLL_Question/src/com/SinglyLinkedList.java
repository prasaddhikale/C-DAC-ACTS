//Design a custom singly linked list which supports following operations.
//1.	add(X) � Add element X at the end of the list.
//2.	add(X, i) � Add element X at index i
//3.	remove(X) � Remove all occurrence of X from the list
//4.	list() � Display all elements.
//5.	reverse() � Reverse the linked list.
//
//
//Marks distribution: 
//1.	Basic structure of classes                  [10]
//2.	Implementation of add(X)                    [5]
//3.	Implementation of add(X,i)                  [5]
//4.	Implementation of remove(X)                 [5]
//5.	Implementation of list()                    [5]
//6.	Implementation of reverse()     ������������[10]



package com;

class Node {
    int value;
    Node next;

    public Node(int value) {
        this.value = value;
        this.next = null;
    }
}

public class SinglyLinkedList {
    private Node head;

    public void add(int X) {
        Node newNode = new Node(X);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public void add(int X, int i) {
        try {
            Node newNode = new Node(X);
            if (i < 0) {
                throw new IndexOutOfBoundsException();
            }
            if (i == 0) {
                newNode.next = head;
                head = newNode;
            } else {
                Node current = head;
                int count = 0;
                while (current != null && count < i - 1) {
                    current = current.next;
                    count++;
                }
                if (current != null) {
                    newNode.next = current.next;
                    current.next = newNode;
                } else {
                    throw new IndexOutOfBoundsException();
                }
            }
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Invalid index. Element cannot be added at this index.");
        }
    }

    public void remove(int X) {
        Node dummy = new Node(-1); // Dummy node to handle cases where X is at the head
        dummy.next = head;
        Node prev = dummy;
        Node current = head;

        while (current != null) {
            if (current.value == X) {
                prev.next = current.next;
            } else {
                prev = current;
            }
            current = current.next;
        }

        head = dummy.next; // Update the head after removals
    }

    public void list() {
        Node current = head;
        while (current != null) {
            System.out.print(current.value + " ");
            current = current.next;
        }
        System.out.println();
    }

    public void reverse() {
        Node prev = null;
        Node current = head;
        Node nextNode;

        while (current != null) {
            nextNode = current.next;
            current.next = prev;
            prev = current;
            current = nextNode;
        }

        head = prev; // Update the head after reversal
    }
}