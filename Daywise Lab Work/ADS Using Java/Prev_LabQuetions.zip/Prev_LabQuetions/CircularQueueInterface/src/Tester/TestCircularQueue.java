package Tester;

import java.util.Scanner;

import com.CircularQueue;
import com.ICircularQueue;

public class TestCircularQueue {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the capacity of the circular queue: ");
        int capacity = scanner.nextInt();

        ICircularQueue circularQueue = new CircularQueue(capacity);
        boolean exit = false;

        while (!exit) {
            System.out.println("\nEnter your choice:");
            System.out.println("1. Add element");
            System.out.println("2. Remove element");
            System.out.println("3. Display size");
            System.out.println("4. Display elements");
            System.out.println("5. Exit");

            try {
                System.out.print("Enter your choice (1-5): ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        System.out.print("Enter element to add: ");
                        scanner.nextLine(); // Consume newline character
                        String elementToAdd = scanner.nextLine();
                        boolean added = circularQueue.add(elementToAdd);
                        if (!added) {
                            System.out.println("Queue is full, element not added.");
                        }
                        break;
                    case 2:
                        String removedElement = circularQueue.remove();
                        if (removedElement == null) {
                            System.out.println("Queue is empty, nothing to remove.");
                        } else {
                            System.out.println("Removed element: " + removedElement);
                        }
                        break;
                    case 3:
                        System.out.println("Size of the queue: " + circularQueue.size());
                        break;
                    case 4:
                        System.out.println("Elements in the queue: " + circularQueue.toString());
                        break;
                    case 5:
                        exit = true;
                        System.out.println("Exiting...");
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter a valid option (1-5).");
                        break;
                }
            } catch (java.util.InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid integer.");
                scanner.nextLine(); // Clear the invalid input
            }
        }

        scanner.close();
    }
}