package com;

public class CircularQueue implements ICircularQueue {
    private String[] queue;
    private int front, rear, size, capacity;

    public CircularQueue(int capacity) {
        this.capacity = capacity;
        queue = new String[capacity];
        front = 0;
        rear = -1;
        size = 0;
    }

    public boolean add(String element) {
        if (isFull()) {
            return false;
        }
        rear = (rear + 1) % capacity;
        queue[rear] = element;
        size++;
        return true;
    }

    public String remove() {
        if (isEmpty()) {
            return null;
        }
        String removed = queue[front];
        queue[front] = null;
        front = (front + 1) % capacity;
        size--;
        return removed;
    }

    public int size() {
        return size;
    }

    @Override
    public String toString() {
        if (isEmpty()) {
            return "";
        }
        StringBuilder result = new StringBuilder();
        int count = 0;
        int index = front;
        while (count < size) {
            result.append(queue[index]);
            if (count < size - 1) {
                result.append(", ");
            }
            index = (index + 1) % capacity;
            count++;
        }
        return result.toString();
    }

    private boolean isFull() {
        return size == capacity;
    }

    private boolean isEmpty() {
        return size == 0;
    }

	@Override
	public boolean add1(String elementToAdd) {
		// TODO Auto-generated method stub
		return false;
	}
}
