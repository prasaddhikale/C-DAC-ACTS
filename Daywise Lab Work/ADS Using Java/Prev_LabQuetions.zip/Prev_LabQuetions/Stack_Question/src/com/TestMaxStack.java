package com;

import java.util.Scanner;

public class TestMaxStack {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MaxStack stack = new MaxStack();
        boolean exit = false;

        while (!exit) {
            System.out.println("\nEnter your choice:");
            System.out.println("1. Push element");
            System.out.println("2. Pop element");
            System.out.println("3. Get top element");
            System.out.println("4. Get maximum element");
            System.out.println("5. Exit");

            try {
                System.out.print("Enter your choice (1-5): ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        System.out.print("Enter element to push: ");
                        int elementToPush = scanner.nextInt();
                        stack.push(elementToPush);
                        break;
                    case 2:
                        int poppedElement = stack.pop();
                        System.out.println("Popped element: " + poppedElement);
                        break;
                    case 3:
                        System.out.println("Top element: " + stack.top());
                        break;
                    case 4:
                        System.out.println("Maximum element: " + stack.getMax());
                        break;
                    case 5:
                        exit = true;
                        System.out.println("Exiting...");
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter a valid option (1-5).");
                        break;
                }
            } catch (java.util.InputMismatchException | IllegalStateException e) {
                System.out.println("Invalid input or stack is empty. Please enter a valid option.");
                scanner.nextLine(); // Clear the invalid input
            }
        }

        scanner.close();
    }
}
