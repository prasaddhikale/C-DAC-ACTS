//Design a custom stack that supports push, pop, top, and retrieving the maximum element in constant time.
//1.	push(x) � Push element x onto stack.
//2.	pop() � Removes the element from the top of the stack.
//3.	top() � Get the top element.
//4.	getMax() � Retrieve the maximum element in the stack.
//
//Methods pop, top and getMax operations will always be called on non-empty stacks.
//
//Marks distribution: 
//1.	Basic structure of classes                  [10]
//2.	Implementation of push()                    [7]
//3.	Implementation of pop()                     [7]
//4.	Implementation of getMax()                  [10]
//5.	Creation/Handling of custom exceptions      [6]
//


package com;

import java.util.Stack;

public class MaxStack {
    private Stack<Integer> mainStack;
    private Stack<Integer> maxStack;

    public MaxStack() {
        mainStack = new Stack<>();
        maxStack = new Stack<>();
    }

    public void push(int x) {
        mainStack.push(x);
        if (maxStack.isEmpty() || x >= maxStack.peek()) {
            maxStack.push(x);
        }
    }

    public int pop() {
        if (mainStack.isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }

        int popped = mainStack.pop();
        if (popped == maxStack.peek()) {
            maxStack.pop();
        }
        return popped;
    }

    public int top() {
        if (mainStack.isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return mainStack.peek();
    }

    public int getMax() {
        if (maxStack.isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return maxStack.peek();
    }
}
