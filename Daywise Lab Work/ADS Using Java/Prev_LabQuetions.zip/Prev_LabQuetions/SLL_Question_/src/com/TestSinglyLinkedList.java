package com;

import java.util.Scanner;

public class TestSinglyLinkedList {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SinglyLinkedList list = new SinglyLinkedList();
        boolean exit = false;

        while (!exit) {
            System.out.println("\nEnter your choice:");
            System.out.println("1. Add element");
            System.out.println("2. Find element");
            System.out.println("3. Display list");
            System.out.println("4. Check if list is sorted");
            System.out.println("5. Exit");

            try {
                System.out.print("Enter your choice (1-5): ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        System.out.print("Enter element to add: ");
                        int element = scanner.nextInt();
                        list.add(element);
                        break;
                    case 2:
                        System.out.print("Enter element to find: ");
                        int findElement = scanner.nextInt();
                        int position = list.find(findElement);
                        if (position != -1) {
                            System.out.println("Position of " + findElement + ": " + position);
                        } else {
                            System.out.println(findElement + " not found in the list.");
                        }
                        break;
                    case 3:
                        System.out.println("List: " + list.toString());
                        break;
                    case 4:
                        boolean isSorted = list.isSorted();
                        System.out.println("Is the list sorted? " + isSorted);
                        break;
                    case 5:
                        exit = true;
                        System.out.println("Exiting...");
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter a valid option (1-5).");
                        break;
                }
            } catch (java.util.InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid integer.");
                scanner.nextLine(); // Clear the invalid input
            }
        }

        scanner.close();
    }
}
