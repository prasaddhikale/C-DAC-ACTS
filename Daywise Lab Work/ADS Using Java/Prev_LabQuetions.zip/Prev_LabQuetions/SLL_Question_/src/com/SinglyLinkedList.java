//Design a custom singly linked list which supports following operations: 
//1.	add(X) � Add element X at the end of the list.
//2.	find(X) � Returns the position of X in the list. Returns -1 if X does not exists in the list. 
//3.	toString() � Returns comma separated elements from start to end.
//4.	isSorted() � Returns true if the list is sorted else false.
//
//Marks distribution: 
//1.	Basic structure of classes                  [10]
//2.	Implementation of add(X)                    [5]
//3.	Implementation of find(X)                   [10]
//4.	Implementation of toString()                [5]
//5.	Implementation of isSorted()                [10]



package com;

class Node {
    int value;
    Node next;

    public Node(int value) {
        this.value = value;
        this.next = null;
    }
}

public class SinglyLinkedList {
    private Node head;

    public void add(int X) {
        Node newNode = new Node(X);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public int find(int X) {
        Node current = head;
        int position = 0;

        while (current != null) {
            if (current.value == X) {
                return position;
            }
            current = current.next;
            position++;
        }

        return -1;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        Node current = head;
        while (current != null) {
            sb.append(current.value);
            if (current.next != null) {
                sb.append(", ");
            }
            current = current.next;
        }
        return sb.toString();
    }

    public boolean isSorted() {
        Node current = head;
        while (current != null && current.next != null) {
            if (current.value > current.next.value) {
                return false;
            }
            current = current.next;
        }
        return true;
    }

    
}
