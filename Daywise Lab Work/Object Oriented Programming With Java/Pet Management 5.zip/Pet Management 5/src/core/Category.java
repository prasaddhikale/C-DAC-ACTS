package core;

public enum Category {
	DOG,CAT,FISH,RABBIT;

}
