package com.app.core;

public enum Material {
	PLASTIC, ALLOYSTEEL, METAL;
	
	public String toString() {
		return name();
	}
}
