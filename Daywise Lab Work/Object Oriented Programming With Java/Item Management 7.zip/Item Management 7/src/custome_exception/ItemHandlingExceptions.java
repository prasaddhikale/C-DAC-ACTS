package custome_exception;

public class ItemHandlingExceptions extends Exception {
	public ItemHandlingExceptions(String mesg) {
		super(mesg);
	}
}
