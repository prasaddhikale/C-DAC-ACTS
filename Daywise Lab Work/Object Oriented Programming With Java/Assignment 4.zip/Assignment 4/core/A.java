package com.cdac.core;


	public class A extends B{
		public A (String s,int i) {
			super(s,i);
			
		}
	

	public void display() {
		System.out.println(s);
		System.out.println(i);
	}
	
}

