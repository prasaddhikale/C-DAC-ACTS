package com.cdac.core;

public class B {
	String s;
	int i;
	
	public  B(String s,int i) {
		this.s=s;
		this.i=i;
		
	}
	
	public void display() {
		System.out.println(s);
		System.out.println(i);
	}
}

