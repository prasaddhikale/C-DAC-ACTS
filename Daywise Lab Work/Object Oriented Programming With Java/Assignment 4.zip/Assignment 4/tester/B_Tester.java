package com.cdac.tester;

import com.cdac.core.A;
import com.cdac.core.B;

public class B_Tester {
	public static void main(String[] args) {
		B b1 = new B("harsh",23);
		A b2 = new A("Hp",6);
		b1.display();
		b2.display();

}
}
