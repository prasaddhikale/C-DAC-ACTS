package bankAcoountAst;

public enum Account {
	SAVING , CURRENT  , LOAN, FD 

}
