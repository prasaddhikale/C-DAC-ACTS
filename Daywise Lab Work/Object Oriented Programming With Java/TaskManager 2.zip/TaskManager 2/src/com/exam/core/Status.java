package com.exam.core;

public enum Status {
	PENDING,IN_PROGRESS,COMPLETED
}
