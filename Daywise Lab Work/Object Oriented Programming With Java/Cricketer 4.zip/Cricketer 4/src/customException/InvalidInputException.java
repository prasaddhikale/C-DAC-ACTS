package customException;
public class InvalidInputException extends Exception {
	public InvalidInputException(String errmsg)
	{
		super(errmsg);
		
		}
		
}
