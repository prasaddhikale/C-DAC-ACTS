const TaskList = ({ tasks }) => {
  console.log("Received Tasks:", tasks);
  return;
};

export default TaskList;
