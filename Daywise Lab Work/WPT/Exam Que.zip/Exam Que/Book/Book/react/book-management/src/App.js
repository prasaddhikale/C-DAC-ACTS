import React from 'react';
import SumTwoNum from './SumTwoNum';

function App() {
  return (
    <div className="App">
      <h1>Sum of Two Numbers</h1>
      <SumTwoNum />
    </div>
  );
}

export default App;
