import React from 'react'

export default function ProductFrom() {
  return (
    <div>ProductFrom</div>
  )
}
