import React from 'react'

export default function ProductList() {
  return (
    <div>ProductList</div>
  )
}
